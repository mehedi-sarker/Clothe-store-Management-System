import GUI.ClothesApp;
import GUI.LoginPage;

public class Start {
    public static void main(String[] args) {
       //ClothesList clothesList = new ClothesList(10);
        
        //clothesList.insert(new Clothe("shirt", "M", "BLUE", "cotton", "2", 250, 5));
        //clothesList.insert(new Clothe("sweatshirt", "M", "BLUE", "cotton", "8", 250, 5));
        //clothesList.insert(new Clothe("T-shirt", "M", "BLUE", "cotton", "4", 250, 5));
        //clothesList.insert(new Clothe("pants", "M", "BLUE", "cotton", "7", 250, 5));
        //clothesList.insert(new Clothe("hoodies", "M", "BLUE", "cotton", "9", 250, 5));
        
       // clothesList.getById("4").setPrice(300);
		//clothesList.getById("4").setColor("pink");
       //clothesList.removeById("8");
       // clothesList.showInfo();
        
        //ClothesApp c = new ClothesApp();
		
       // c.show();
	   LoginPage log=new  LoginPage();
	   //IDandPass idpass=new IDandPass();
	   //idpass.getLoginInfo();
	   //javLoginPage loginp=new LoginPage();
	   
    }
}
